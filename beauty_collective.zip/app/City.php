<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class City extends Model
{
  public function getFullLocationAttribute()
	{
    return $this->location . ", " . $this->state . " " . $this->postcode;
	}
}
