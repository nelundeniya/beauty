@include('shared.header')
	
@yield('content')

@include('shared.footer')