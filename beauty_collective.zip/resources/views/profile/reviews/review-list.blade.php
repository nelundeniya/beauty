@extends('profile')

@section('left-links')
	@include('profile.left-links')
@endsection

@section('content')
<div style="border-left: solid 1px #a1a1a1; min-height: 300px;">
	<div class="row">
		<div class="medium-12 columns">
		
		</div>
	</div>
</div>
@endsection