<li><a href="/profile/account" class="db-left-link">Account Details</a></li>
<li><a href="/profile/reviews" class="db-left-link">User Reviews</a></li>
<li><a href="/profile/jobs" class="db-left-link">Job Preferences</a></li>