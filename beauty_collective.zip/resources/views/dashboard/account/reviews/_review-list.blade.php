<div class="row">
  <div class="medium-12 columns">
    <span class="left db-review-stats"><?php echo ' 4 Reviews'; ?></span>
    <span class="left db-review-stats"><?php echo "Overall Rating: 4.5"; ?></span>
  </div>
</div>