<div class="content active" id="panel1">
  @include('dashboard.account.reviews._review-list')
</div>
<div class="content" id="panel2">
  <?php //$this->load->view('dashboard/account/reviews/request-review'); ?>
</div>
<div class="content" id="panel3">
  <?php //$this->load->view('dashboard/account/reviews/submit-review'); ?>
</div>
<div class="content" id="panel4">
  <?php //$this->load->view('dashboard/account/reviews/review-faq'); ?>
</div>