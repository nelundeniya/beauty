<li class="tab-title active"><a href="#panel1" style="border-left: none !important;">Review Dashboard</a></li>
<li class="tab-title"><a href="#panel2">Request Reviews</a></li>
<li class="tab-title"><a href="#panel3">Submit Reviews</a></li>
<li class="tab-title"><a href="#panel4">Review FAQ</a></li>