<li class="tab-title active"><a href="#panel1" style="border-left: none !important;">Account Details</a></li>
<li class="tab-title"><a href="#panel2">Subscription</a></li>
<li class="tab-title"><a href="#panel3">Payment Details</a></li>
<li class="tab-title"><a href="#panel4">Invoices</a></li>