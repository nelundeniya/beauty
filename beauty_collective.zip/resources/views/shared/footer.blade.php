	<div class="row">
		<div class="medium-12 columns" style="margin-top:40px; border-top: solid 3px #c5c5c5; height:100px;">
		
		</div>
	</div>
	<!-- Scripts -->
	<script src="{{ asset('/js/vendor.js') }}"></script>
	<script src="{{ asset('/js/jquery-ui.js') }}"></script>
	<script src="{{ asset('/js/app.js') }}"></script>
	
</body>
</html>